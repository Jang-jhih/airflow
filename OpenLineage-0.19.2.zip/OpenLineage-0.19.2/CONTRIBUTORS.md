# Contributors to OpenLineage


This file recognizes the people who have make an important contribution to OpenLineage.

| Name           | Email or GitHub Id |
| -------------- | -----------------
| Howard Yoo | howardyoo |



To understand how to become an OpenLineage contributor see the [OpenLineage Contributing Guide](CONTRIBUTING.md).

----
SPDX-License-Identifier: Apache-2.0\
Copyright 2018-2022 contributors to the OpenLineage project
