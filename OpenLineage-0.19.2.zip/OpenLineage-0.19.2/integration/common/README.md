Common modules for OpenLineage integrations.
