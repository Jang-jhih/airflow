# Copyright 2018-2022 contributors to the OpenLineage project
# SPDX-License-Identifier: Apache-2.0

GITHUB_LOCATION = "https://github.com/OpenLineage/OpenLineage/tree/main/integration/common/openlineage/schema/"  # noqa: E501
