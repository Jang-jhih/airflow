# Copyright 2018-2022 contributors to the OpenLineage project
# SPDX-License-Identifier: Apache-2.0

import os

from openlineage.dagster.adapter import OpenLineageAdapter


def test_custom_client_config():
    os.environ["OPENLINEAGE_URL"] = "http://ol-api:5000"
    os.environ["OPENLINEAGE_API_KEY"] = "api-key"
    adapter = OpenLineageAdapter()
    assert adapter._client.transport.url == "http://ol-api:5000"
    assert adapter._client.transport.session.headers['Authorization'] == "Bearer api-key"
    del os.environ["OPENLINEAGE_URL"]
    del os.environ["OPENLINEAGE_API_KEY"]
