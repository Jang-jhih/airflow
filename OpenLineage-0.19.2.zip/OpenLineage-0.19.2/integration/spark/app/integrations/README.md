This folder contains the expected json events for the spark agent.

It can be regenerated if the `UPDATE_SNAPSHOT` env variable is set.